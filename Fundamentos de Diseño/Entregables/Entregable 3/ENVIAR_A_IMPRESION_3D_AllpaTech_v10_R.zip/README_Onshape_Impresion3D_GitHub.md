# Módulo Mecánico — Modelo 3D Final, Archivos `.STL`, Planos `.PDF` y Links de Onshape (`AllpaTech_v10_R`)

**Curso:** Fundamentos de Diseño 2026-2 — Universidad Peruana Cayetano Heredia (UPCH)  
**Equipo:** Equipo 07  
**Integrantes:** Johan Daymar Chara Franco · Wilmer Sebastian Herrera Neira · Alessandra Nicol Palomino Lima · José Luis Cepida Castellares · José Junior Bances Panaque  

---

## 1. Enlaces Directos al Modelo 3D en Onshape (`AllpaTech_v10_R`)

- **🔗 Ensamble General Completo (`AllpaTech_v10_TOMAMUESTRAS_EXPERIMENTAL`):**  
  https://cad.onshape.com/documents/f575495a139d8a5fc4880768/w/ca19eeaafa5b85a1cc946281/e/a2b005eef20a6a694cf7a657
- **🔗 Part Studio con Todas las Piezas Sólidas (`AllpaTech_v10_bicamara_conjunto parts`):**  
  https://cad.onshape.com/documents/f575495a139d8a5fc4880768/w/ca19eeaafa5b85a1cc946281/e/172e089adf4505ffc99ab023

### Estructura Modular en Onshape:
1. **`Cuerpo 1 - Cabezal y tanque`:** Carcasa principal de $150 \times 110\text{ mm}$ con frente inclinado a $30^\circ$ para pantalla LCD 1602 I2C, LED indicador y pulsador, bandeja electrónica interna, soporte extraíble para placa TDS, cajón lateral de baterías, compartimento húmedo posterior aislado con depósito de agua de $79\text{ mL}$ y 8 tornillos `Hex socket head cap screw M3x0.50 x 8`.
2. **`Cuerpo 2 - Cuello y bateria`:** Cilindro bicámara ($\varnothing 68\text{ mm}$, tabique divisorio de $12\text{ mm}$) con cámara frontal en seco (sensor capacitivo de humedad + sonda DS18B20) y cámara posterior acuosa (sondas pH BNC y TDS protegidas por jaulas perforadas extraíbles), mecanismo de compuerta rotativa inferior de $90^\circ$ y canal húmedo lateral protegido.
3. **`Cuerpo 3 - Estaca M3`:** Punta perforadora hueca biselada desmontable con entradas sectoriales de suelo, fijada mediante 3 tornillos `Hex socket head cap screw M3x0.50 x 8`.

---

## 2. Tabla de las 20 Piezas a Fabricar (Modelos `.STL` y Planos Individuales `.PDF`)

- **📄 Plano Maestro Consolidado (22 Láminas A4 — Ensamble + BOM + 20 Piezas):** [`Planos_Tecnicos_AllpaTech_v10_R_COMPLETO.pdf`](./04_Planos_Tecnicos_PDF/Planos_Tecnicos_AllpaTech_v10_R_COMPLETO.pdf)
- **📄 Lámina 01 — Ensamble General y Lista de Materiales (BOM):** [`00_Plano_Ensamble_General_y_BOM.pdf`](./04_Planos_Tecnicos_PDF/00_Plano_Ensamble_General_y_BOM.pdf)

| Ítem | Pieza a Fabricar | Subensamble Onshape | Cant. | Dimensiones (mm) | Modelo `.STL` (Impresión 3D) | Plano Técnico `.PDF` (A4 Acotado) |
| :-: | :--- | :--- | :-: | :---: | :--- | :--- |
| **01** | Carcasa con compartimento húmedo | Cuerpo 1 - Cabezal y tanque | 1 | 150.0 × 149.0 × 80.0 | [`01_carcasa_con_compartimento_humedo.stl`](./03_STL_Listos_Para_Imprimir/01_carcasa_con_compartimento_humedo.stl) | [`Plano_01_carcasa_con_compartimento_humedo.pdf`](./04_Planos_Tecnicos_PDF/Plano_01_carcasa_con_compartimento_humedo.pdf) |
| **02** | Tapa superior | Cuerpo 1 - Cabezal y tanque | 1 | 150.0 × 84.0 × 4.0 | [`02_tapa_superior.stl`](./03_STL_Listos_Para_Imprimir/02_tapa_superior.stl) | [`Plano_02_tapa_superior.pdf`](./04_Planos_Tecnicos_PDF/Plano_02_tapa_superior.pdf) |
| **03** | Bandeja extraíble ajustable | Cuerpo 1 - Cabezal y tanque | 1 | 140.0 × 86.0 × 7.0 | [`03_bandeja_extraible_ajustable.stl`](./03_STL_Listos_Para_Imprimir/03_bandeja_extraible_ajustable.stl) | [`Plano_03_bandeja_extraible_ajustable.pdf`](./04_Planos_Tecnicos_PDF/Plano_03_bandeja_extraible_ajustable.pdf) |
| **04** | Cajón de baterías | Cuerpo 1 - Cabezal y tanque | 1 | 54.0 × 93.0 × 30.0 | [`04_cajon_2x18650.stl`](./03_STL_Listos_Para_Imprimir/04_cajon_2x18650.stl) | [`Plano_04_cajon_2x18650.pdf`](./04_Planos_Tecnicos_PDF/Plano_04_cajon_2x18650.pdf) |
| **05** | Tapa compartimento húmedo | Cuerpo 1 - Cabezal y tanque | 1 | 78.0 × 39.0 × 4.0 | [`05_tapa_compartimento_humedo.stl`](./03_STL_Listos_Para_Imprimir/05_tapa_compartimento_humedo.stl) | [`Plano_05_tapa_compartimento_humedo.pdf`](./04_Planos_Tecnicos_PDF/Plano_05_tapa_compartimento_humedo.pdf) |
| **06** | Depósito integrado 79 mL | Cuerpo 1 - Cabezal y tanque | 1 | 64.0 × 30.0 × 80.0 | [`06_deposito_integrado_79mL_PRUEBA.stl`](./03_STL_Listos_Para_Imprimir/06_deposito_integrado_79mL_PRUEBA.stl) | [`Plano_06_deposito_integrado_79mL_PRUEBA.pdf`](./04_Planos_Tecnicos_PDF/Plano_06_deposito_integrado_79mL_PRUEBA.pdf) |
| **07** | Tapa depósito ventilada | Cuerpo 1 - Cabezal y tanque | 1 | 64.0 × 30.0 × 12.0 | [`07_tapa_deposito_ventilada.stl`](./03_STL_Listos_Para_Imprimir/07_tapa_deposito_ventilada.stl) | [`Plano_07_tapa_deposito_ventilada.pdf`](./04_Planos_Tecnicos_PDF/Plano_07_tapa_deposito_ventilada.pdf) |
| **08** | Apoyo de depósito | Cuerpo 1 - Cabezal y tanque | 1 | 68.0 × 30.0 × 6.0 | [`08_apoyo_deposito.stl`](./03_STL_Listos_Para_Imprimir/08_apoyo_deposito.stl) | [`Plano_08_apoyo_deposito.pdf`](./04_Planos_Tecnicos_PDF/Plano_08_apoyo_deposito.pdf) |
| **09** | Tapa puerto USB desmontable | Cuerpo 1 - Cabezal y tanque | 1 | 3.0 × 48.0 × 20.0 | [`09_tapa_USB_DESMONTADA.stl`](./03_STL_Listos_Para_Imprimir/09_tapa_USB_DESMONTADA.stl) | [`Plano_09_tapa_USB_DESMONTADA.pdf`](./04_Planos_Tecnicos_PDF/Plano_09_tapa_USB_DESMONTADA.pdf) |
| **10** | Cilindro bicámara con división | Cuerpo 2 - Cuello y bateria | 1 | 98.0 × 98.0 × 119.6 | [`10_cilindro_bicamara_con_division.stl`](./03_STL_Listos_Para_Imprimir/10_cilindro_bicamara_con_division.stl) | [`Plano_10_cilindro_bicamara_con_division.pdf`](./04_Planos_Tecnicos_PDF/Plano_10_cilindro_bicamara_con_division.pdf) |
| **11** | Punta hueca biselada desmontable | Cuerpo 3 - Estaca M3 | 1 | 76.0 × 76.0 × 15.8 | [`11_punta_hueca_biselada_desmontable.stl`](./03_STL_Listos_Para_Imprimir/11_punta_hueca_biselada_desmontable.stl) | [`Plano_11_punta_hueca_biselada_desmontable.pdf`](./04_Planos_Tecnicos_PDF/Plano_11_punta_hueca_biselada_desmontable.pdf) |
| **12** | Compuerta rotativa 90° | Cuerpo 2 - Cuello y bateria | 1 | 60.0 × 60.0 × 4.0 | [`12_compuerta_rotativa_ABIERTA.stl`](./03_STL_Listos_Para_Imprimir/12_compuerta_rotativa_ABIERTA.stl) | [`Plano_12_compuerta_rotativa_ABIERTA.pdf`](./04_Planos_Tecnicos_PDF/Plano_12_compuerta_rotativa_ABIERTA.pdf) |
| **13** | Eje y mando giro 90° | Cuerpo 2 - Cuello y bateria | 1 | 85.5 × 77.0 × 117.4 | [`13_eje_y_mando_giro90.stl`](./03_STL_Listos_Para_Imprimir/13_eje_y_mando_giro90.stl) | [`Plano_13_eje_y_mando_giro90.pdf`](./04_Planos_Tecnicos_PDF/Plano_13_eje_y_mando_giro90.pdf) |
| **14** | Tapa cojinete y cables | Cuerpo 2 - Cuello y bateria | 1 | 59.4 × 59.4 × 4.0 | [`14_tapa_cojinete_y_cables.stl`](./03_STL_Listos_Para_Imprimir/14_tapa_cojinete_y_cables.stl) | [`Plano_14_tapa_cojinete_y_cables.pdf`](./04_Planos_Tecnicos_PDF/Plano_14_tapa_cojinete_y_cables.pdf) |
| **15** | Tapa cámara sin agua (seco) | Cuerpo 2 - Cuello y bateria | 1 | 58.2 × 23.7 × 3.0 | [`15_tapa_camara_sin_agua.stl`](./03_STL_Listos_Para_Imprimir/15_tapa_camara_sin_agua.stl) | [`Plano_15_tapa_camara_sin_agua.pdf`](./04_Planos_Tecnicos_PDF/Plano_15_tapa_camara_sin_agua.pdf) |
| **16** | Tapa y protectores de sondas extraíble | Cuerpo 2 - Cuello y bateria | 1 | 58.2 × 23.7 × 65.0 | [`16_tapa_y_protectores_sondas_EXTRAIBLE.stl`](./03_STL_Listos_Para_Imprimir/16_tapa_y_protectores_sondas_EXTRAIBLE.stl) | [`Plano_16_tapa_y_protectores_sondas_EXTRAIBLE.pdf`](./04_Planos_Tecnicos_PDF/Plano_16_tapa_y_protectores_sondas_EXTRAIBLE.pdf) |
| **17** | Canal húmedo protección manguera | Cuerpo 2 - Cuello y bateria | 1 | 19.0 × 53.6 × 40.0 | [`18_canal_humedo_proteccion_manguera.stl`](./03_STL_Listos_Para_Imprimir/18_canal_humedo_proteccion_manguera.stl) | [`Plano_18_canal_humedo_proteccion_manguera.pdf`](./04_Planos_Tecnicos_PDF/Plano_18_canal_humedo_proteccion_manguera.pdf) |
| **18** | Tapa lateral del canal húmedo | Cuerpo 2 - Cuello y bateria | 1 | 2.0 × 55.0 × 40.0 | [`19_tapa_lateral_canal.stl`](./03_STL_Listos_Para_Imprimir/19_tapa_lateral_canal.stl) | [`Plano_19_tapa_lateral_canal.pdf`](./04_Planos_Tecnicos_PDF/Plano_19_tapa_lateral_canal.pdf) |
| **19** | Tapón de llenado ventilado | Cuerpo 1 - Cabezal y tanque | 1 | 21.6 × 21.6 × 6.0 | [`20_tapon_llenado_ventilado.stl`](./03_STL_Listos_Para_Imprimir/20_tapon_llenado_ventilado.stl) | [`Plano_20_tapon_llenado_ventilado.pdf`](./04_Planos_Tecnicos_PDF/Plano_20_tapon_llenado_ventilado.pdf) |
| **20** | Soporte extraíble placa TDS | Cuerpo 1 - Cabezal y tanque | 1 | 57.0 × 50.0 × 24.0 | [`21_soporte_extraible_placa_TDS.stl`](./03_STL_Listos_Para_Imprimir/21_soporte_extraible_placa_TDS.stl) | [`Plano_21_soporte_extraible_placa_TDS.pdf`](./04_Planos_Tecnicos_PDF/Plano_21_soporte_extraible_placa_TDS.pdf) |

---

## 3. Especificaciones de Fabricación (Impresión 3D FDM)
- **Material:** PETG (o ASA / PLA+ según disponibilidad del laboratorio).
- **Boquilla / Capa:** Boquilla `0.4 mm`, altura de capa `0.20 mm`.
- **Paredes y Capas Sólidas:** `5 a 6 perímetros`, `6 capas` superiores e inferiores.
- **Relleno (Infill):** `40%` en carcasa, tapas y soportes; `80% a 100%` en la punta perforadora (`11`), compuerta rotativa (`12`) y eje/mando (`13`).
- **Plantilla escala 1:1 para corte de junta elastomérica (0.8 mm):** [`Plantilla_junta_compuerta_1a1.svg`](./Plantilla_junta_compuerta_1a1.svg) y [`22_Plano_Funcional_Compuerta_y_Junta.pdf`](./04_Planos_Tecnicos_PDF/22_Plano_Funcional_Compuerta_y_Junta.pdf).
