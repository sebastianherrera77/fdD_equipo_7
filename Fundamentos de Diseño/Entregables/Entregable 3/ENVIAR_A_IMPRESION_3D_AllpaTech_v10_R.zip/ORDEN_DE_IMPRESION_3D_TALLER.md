# Orden de Impresión 3D para Taller — AllpaTech v10_R (Equipo 07 - UPCH)

## 1. Resumen del Pedido
- **Cantidad total de piezas a imprimir:** **20 piezas** (1 unidad de cada archivo numerado del `01` al `21`, no existe pieza `17`).
- **Unidades de todos los archivos `.STL` y `.STEP`:** **Milímetros (mm)**.
- **IMPORTANTE (Qué NO imprimir):** No enviar el archivo de ensamble completo (`AllpaTech_v10_R_ENSAMBLE_COMPLETO.step`) a la impresora, ya que ese archivo contiene placas electrónicas (`CAD_...`), baterías, juntas flexibles (`REF_...`) y tornillos metálicos M3. **Imprimir únicamente los 20 archivos numerados (`01_` al `21_`)**.

---

## 2. Parámetros Generales de Laminado (Slicer) Recomendados
- **Material:** **PETG** (recomendado por resistencia mecánica y contacto con agua; alternativa: **ASA** o **PLA+** si el taller solo trabaja PLA en primera prueba).
- **Boquilla:** `0.4 mm`
- **Altura de capa:** `0.20 mm`
- **Perímetros (paredes):** `5 a 6 líneas` (garantiza estanqueidad en el depósito `06` y rigidez en roscas/bridas M3).
- **Capas superiores e inferiores:** `6 capas` (`1.2 mm`).
- **Relleno (Infill):**
  - `35% a 45%` (patrón *Gyroid* o *Grid*) para carcasas y tapas (`01` a `10`, `14` a `21`).
  - `80% a 100%` (macizo) para las 3 piezas de esfuerzo mecánico directo: **`11_punta_hueca_biselada_desmontable`**, **`12_compuerta_rotativa_ABIERTA`** y **`13_eje_y_mando_giro90`**.

---

## 3. Lista Exacta de los 20 Archivos a Imprimir (1 unidad de cada uno)

| # | Archivo (`.stl` / `.step`) | Cant. | Dimensiones (mm) | Relleno | Orientación Recomendada en Cama |
| :-: | :--- | :-: | :---: | :---: | :--- |
| 1 | `01_carcasa_con_compartimento_humedo` | 1 | 150 × 149 × 80 | 40% | Base plana inferior sobre cama ($Z=0$) |
| 2 | `02_tapa_superior` | 1 | 150 × 84 × 4 | 40% | Cara plana sobre cama (sin soportes) |
| 3 | `03_bandeja_extraible_ajustable` | 1 | 140 × 86 × 7 | 40% | Base plana sobre cama, soportes de PCB hacia arriba |
| 4 | `04_cajon_2x18650` | 1 | 54 × 93 × 30 | 40% | Base del cajón plana sobre cama |
| 5 | `05_tapa_compartimento_humedo` | 1 | 78 × 39 × 4 | 40% | Cara plana sobre cama (sin soportes) |
| 6 | `06_deposito_integrado_79mL_PRUEBA` | 1 | 64 × 30 × 80 | 45% (6 perím.) | Boca hacia arriba; soporte exterior bajo piso dejando libre espiga $\varnothing 4\text{ mm}$ |
| 7 | `07_tapa_deposito_ventilada` | 1 | 64 × 30 × 12 | 40% | Cara plana inferior sobre cama, cuello hacia arriba |
| 8 | `08_apoyo_deposito` | 1 | 68 × 30 × 6 | 40% | Cara plana sobre cama |
| 9 | `09_tapa_USB_DESMONTADA` | 1 | 3 × 48 × 20 | 40% | Cara plana de $48 \times 20\text{ mm}$ acostada sobre cama |
| 10 | `10_cilindro_bicamara_con_division` | 1 | 98 × 98 × 120 | 45% | Eje vertical; no dejar soportes atrapados en el canal interior |
| 11 | `11_punta_hueca_biselada_desmontable` | 1 | 76 × 76 × 16 | **80–100%** | Cara anular plana sobre cama |
| 12 | `12_compuerta_rotativa_ABIERTA` | 1 | 60 × 60 × 4 | **80–100%** | Cara plana sobre cama (debe quedar lisa para deslizar) |
| 13 | `13_eje_y_mando_giro90` | 1 | 86 × 77 × 117 | **80–100%** | Revisar orientación con soporte para máxima resistencia torsional del eje |
| 14 | `14_tapa_cojinete_y_cables` | 1 | 59 × 59 × 4 | 40% | Cara plana sobre cama |
| 15 | `15_tapa_camara_sin_agua` | 1 | 58 × 24 × 3 | 40% | Cara plana sobre cama |
| 16 | `16_tapa_y_protectores_sondas_EXTRAIBLE` | 1 | 58 × 24 × 65 | 45% | Invertida: tapa semicircular apoyada en cama y jaulas perforadas hacia arriba |
| 17 | `18_canal_humedo_proteccion_manguera` | 1 | 19 × 54 × 40 | 40% | Cara plana exterior apoyada en cama |
| 18 | `19_tapa_lateral_canal` | 1 | 2 × 55 × 40 | 40% | Cara plana de $55 \times 40\text{ mm}$ acostada sobre cama |
| 19 | `20_tapon_llenado_ventilado` | 1 | 22 × 22 × 6 | 40% | Tope circular superior plano sobre cama |
| 20 | `21_soporte_extraible_placa_TDS` | 1 | 57 × 50 × 24 | 40% | Invertido: plataforma plana sobre cama y las 4 columnas hacia arriba |
