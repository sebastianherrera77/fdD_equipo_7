# Plantilla de Correo de Impresión 3D — Equipo 07 (AllpaTech v10_R)

**Asunto:** Solicitud de Impresión 3D (Versión Final) — Equipo 07 — Fundamentos de Diseño (AllpaTech v10_R)

---

**Cuerpo del correo:**

Estimados responsables del Área de Fabricación / Impresión 3D (y/o Docente del curso Fundamentos de Diseño),

Reciban un cordial saludo de parte del **Equipo 07** del curso **Fundamentos de Diseño (UPCH)**. Por medio del presente correo enviamos la **versión final lista para fabricación por Impresión 3D** de nuestro prototipo de monitoreo fisicoquímico de suelos **AllpaTech (`AllpaTech_v10_R`)**, incluyendo todos los modelos `.STL` individuales, los planos técnicos acotados en `.PDF` de cada parte a fabricar y los enlaces a nuestro documento de Onshape y repositorio de GitHub.

### 1. Enlaces de Onshape y Repositorio GitHub
- **Documento Onshape (Ensamble General `AllpaTech_v10_R`):**  
  https://cad.onshape.com/documents/f575495a139d8a5fc4880768/w/ca19eeaafa5b85a1cc946281/e/a2b005eef20a6a694cf7a657
- **Part Studio Onshape (`AllpaTech_v10_bicamara_conjunto parts`):**  
  https://cad.onshape.com/documents/f575495a139d8a5fc4880768/w/ca19eeaafa5b85a1cc946281/e/172e089adf4505ffc99ab023
- **Repositorio de GitHub del Equipo 07 (con archivo `.MD`, `.STL` y Planos `.PDF`):**  
  https://github.com/sebastianherrera77/fdD_equipo_7

### 2. Archivos Adjuntos para Fabricación
Adjuntamos el paquete **`ENVIAR_A_IMPRESION_3D_AllpaTech_v10_R.zip`**, el cual contiene:
1. **`03_STL_Listos_Para_Imprimir/`:** Los **20 archivos `.STL` individuales** (numerados del `01` al `21`, sin `17`), cerrados (`watertight`), orientados con su base en $Z = 0\text{ mm}$ y exportados en **milímetros (mm)**.
2. **`04_Planos_Tecnicos_PDF/`:**
   - Los **20 planos técnicos individuales en `.PDF`** de cada pieza a fabricar (`Plano_01_...pdf` a `Plano_21_...pdf`), con sus 3 vistas ortográficas acotadas (Frontal, Lateral, Superior), vista isométrica 3D, tolerancias y cajetín normalizado.
   - El plano general de ensamble y lista de materiales (BOM): `00_Plano_Ensamble_General_y_BOM.pdf` y el consolidado `Planos_Tecnicos_AllpaTech_v10_R_COMPLETO.pdf`.
3. **`01_STEP_Piezas_Imprimibles/`:** Los **20 archivos `.STEP`** individuales de respaldo.

### 3. Resumen de Piezas a Imprimir (20 piezas en total — 1 unidad de cada una)
- **Cuerpo 1 (Cabezal y tanque):**
  - `01_carcasa_con_compartimento_humedo.stl` (1 ud. — 150 × 149 × 80 mm)
  - `02_tapa_superior.stl` (1 ud. — 150 × 84 × 4 mm)
  - `03_bandeja_extraible_ajustable.stl` (1 ud. — 140 × 86 × 7 mm)
  - `04_cajon_2x18650.stl` (1 ud. — 54 × 93 × 30 mm)
  - `05_tapa_compartimento_humedo.stl` (1 ud. — 78 × 39 × 4 mm)
  - `06_deposito_integrado_79mL_PRUEBA.stl` (1 ud. — 64 × 30 × 80 mm)
  - `07_tapa_deposito_ventilada.stl` (1 ud. — 64 × 30 × 12 mm)
  - `08_apoyo_deposito.stl` (1 ud. — 68 × 30 × 6 mm)
  - `09_tapa_USB_DESMONTADA.stl` (1 ud. — 3 × 48 × 20 mm)
  - `20_tapon_llenado_ventilado.stl` (1 ud. — 22 × 22 × 6 mm)
  - `21_soporte_extraible_placa_TDS.stl` (1 ud. — 57 × 50 × 24 mm)
- **Cuerpo 2 (Cuello y batería / módulo bicámara):**
  - `10_cilindro_bicamara_con_division.stl` (1 ud. — 98 × 98 × 120 mm)
  - `12_compuerta_rotativa_ABIERTA.stl` (1 ud. — 60 × 60 × 4 mm)
  - `13_eje_y_mando_giro90.stl` (1 ud. — 86 × 77 × 117 mm)
  - `14_tapa_cojinete_y_cables.stl` (1 ud. — 59 × 59 × 4 mm)
  - `15_tapa_camara_sin_agua.stl` (1 ud. — 58 × 24 × 3 mm)
  - `16_tapa_y_protectores_sondas_EXTRAIBLE.stl` (1 ud. — 58 × 24 × 65 mm)
  - `18_canal_humedo_proteccion_manguera.stl` (1 ud. — 19 × 54 × 40 mm)
  - `19_tapa_lateral_canal.stl` (1 ud. — 2 × 55 × 40 mm)
- **Cuerpo 3 (Estaca M3):**
  - `11_punta_hueca_biselada_desmontable.stl` (1 ud. — 76 × 76 × 16 mm)

### 4. Parámetros de Impresión Solicitados
- **Material:** PETG (o PLA+ / ASA según disponibilidad del laboratorio).
- **Boquilla / Capa:** Boquilla `0.4 mm`, altura de capa `0.20 mm`.
- **Perímetros y Capas Sólidas:** `5 a 6 perímetros`, `6 capas` superiores/inferiores.
- **Relleno (Infill):** `40%` general; `80% a 100%` en las piezas de esfuerzo mecánico `11_punta_hueca_biselada_desmontable`, `12_compuerta_rotativa_ABIERTA` y `13_eje_y_mando_giro90`.

Quedamos atentos a cualquier confirmación o indicación del laboratorio. Muchas gracias.

Atentamente,  
**Equipo 07 — Fundamentos de Diseño (UPCH)**  
- Johan Daymar Chara Franco  
- Wilmer Sebastian Herrera Neira  
- Alessandra Nicol Palomino Lima  
- José Luis Cepida Castellares  
- José Junior Bances Panaque  
